
/**
 * Proportional share scheduler
 * Take total shares to be 100.
 * A process will not run unless it is completely given the requested share.
 */
public class PSScheduler implements Scheduler {

  @Override
  public void schedule(String inputFile, String outputFile) {
    // implement your scheduler here.
    // write the scheduler output to {@code outputFile}
  }
}
